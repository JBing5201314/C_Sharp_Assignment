﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace IOOP_Assignment
{
    public partial class Login_Form : Form
    {
        public Login_Form()
        {
            InitializeComponent();
        }
        OleDbConnection cnnOLEDB = new OleDbConnection();
        OleDbCommand cmdSearch = new OleDbCommand();
        public static string account;
        private void Login_Form_Load(object sender, EventArgs e)
        {
            cnnOLEDB.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=IOOP Assignment.mdb;";
            cnnOLEDB.Open();
        }

        private void accounttextBox_TextChanged(object sender, EventArgs e)
        {
            if (accounttextBox.Text != "")
            {
                clearAccountpictureBox.Show();
            }
            else
            {
                clearAccountpictureBox.Hide();
            }
        }

        private void passwordtextBox_TextChanged(object sender, EventArgs e)
        {
            
            if (passwordtextBox.Text != "")
            {
                clearPasswordpictureBox.Show();
            }
            else
            {
                clearPasswordpictureBox.Hide();
            }
        }

        private void clearAccountpictureBox_Click(object sender, EventArgs e)
        {
            if (passwordtextBox.Text != "")
            {
                passwordtextBox.Clear();
            }
            accounttextBox.Clear();
            accounttextBox.Select();
        }

        private void clearPasswordpictureBox_Click(object sender, EventArgs e)
        {
            passwordtextBox.Clear();
            if (accounttextBox.Text == "")
            {
                accounttextBox.Select();
            }
            else
            {
                passwordtextBox.Select();
            }

        }

        private void forgotpasswordlinkLabel_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("Please contact manager");
            accounttextBox.Clear();
            passwordtextBox.Clear();
            accounttextBox.Select();
        }

        private void loginbutton_Click(object sender, EventArgs e)
        {
            if (accounttextBox.Text == "")
            {
                MessageBox.Show("Please enter account first");
                passwordtextBox.Clear();
                accounttextBox.Select();
                return;
            }
            if (passwordtextBox.Text == "")
            {
                MessageBox.Show("Please enter password first");
                passwordtextBox.Select();
                return;
            }
            string inputPassword, Saved_password;
            account = accounttextBox.Text;
            inputPassword = passwordtextBox.Text;
            cmdSearch.CommandText = "Select * from Account_Password where Account = \'" + accounttextBox.Text + "\';";
            cmdSearch.Connection = cnnOLEDB;
            OleDbDataReader dr = cmdSearch.ExecuteReader();
            if (dr.Read() == true)
            {
                Saved_password = dr[1].ToString();
                if (inputPassword == Saved_password)
                {
                    this.Hide();
                    Loading_Form loading_form = new Loading_Form();
                    loading_form.ShowDialog();
                    Home_Form home_form = new Home_Form();
                    home_form.Show();
                }
                else
                {
                    MessageBox.Show("Password is not correct");
                    passwordtextBox.Clear();
                    dr.Close();
                    return;
                }              
            }
            else
            {
                MessageBox.Show("Sorry, account not found");
                accounttextBox.Clear();
                passwordtextBox.Clear();
                accounttextBox.Select();
                dr.Close();
                //cnnOLEDB.Close();
                return;
            }
            
        }

        private void exitbutton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
