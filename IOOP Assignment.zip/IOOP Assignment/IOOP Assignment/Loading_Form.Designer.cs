﻿namespace IOOP_Assignment
{
    partial class Loading_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Loading_Form));
            this.loadingpictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.loadingpictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // loadingpictureBox
            // 
            this.loadingpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("loadingpictureBox.Image")));
            this.loadingpictureBox.Location = new System.Drawing.Point(-40, 12);
            this.loadingpictureBox.Name = "loadingpictureBox";
            this.loadingpictureBox.Size = new System.Drawing.Size(500, 500);
            this.loadingpictureBox.TabIndex = 0;
            this.loadingpictureBox.TabStop = false;
            // 
            // Loading_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(484, 461);
            this.Controls.Add(this.loadingpictureBox);
            this.Name = "Loading_Form";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Pacific Reservation System";
            this.Load += new System.EventHandler(this.Loading_Form_Load);
            ((System.ComponentModel.ISupportInitialize)(this.loadingpictureBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox loadingpictureBox;
    }
}