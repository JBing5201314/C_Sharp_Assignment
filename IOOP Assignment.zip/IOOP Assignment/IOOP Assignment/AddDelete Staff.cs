﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace IOOP_Assignment
{
    public partial class AddDelete_Staff : Form
    {
        private IContainer components;
        private RadioButton addradioButton;
        private RadioButton deleteradioButton;
        private Label titlelabel;
        private TextBox accounttextBox;
        private Button savebutton;
        private Button cancelbutton;
        private TextBox passwordtextBox;
        private Label accountlabel;
        private DataGridView dataGridView1;
        private IOOP_AssignmentDataSet1 iOOP_AssignmentDataSet1;
        private BindingSource accountPasswordBindingSource;
        private IOOP_AssignmentDataSet1TableAdapters.Account_PasswordTableAdapter account_PasswordTableAdapter;
        private DataGridViewTextBoxColumn accountDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn passwordDataGridViewTextBoxColumn;
        private Label passwordlabel;

        public AddDelete_Staff()
        {
            InitializeComponent();
        }
        OleDbConnection cnnOLEDB = new OleDbConnection();
        OleDbCommand cmdInsert = new OleDbCommand();
        OleDbCommand cmdDelete = new OleDbCommand();
        OleDbCommand cmdSearch = new OleDbCommand();
        
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.addradioButton = new System.Windows.Forms.RadioButton();
            this.deleteradioButton = new System.Windows.Forms.RadioButton();
            this.titlelabel = new System.Windows.Forms.Label();
            this.accounttextBox = new System.Windows.Forms.TextBox();
            this.savebutton = new System.Windows.Forms.Button();
            this.cancelbutton = new System.Windows.Forms.Button();
            this.passwordtextBox = new System.Windows.Forms.TextBox();
            this.accountlabel = new System.Windows.Forms.Label();
            this.passwordlabel = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.iOOP_AssignmentDataSet1 = new IOOP_Assignment.IOOP_AssignmentDataSet1();
            this.accountPasswordBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.account_PasswordTableAdapter = new IOOP_Assignment.IOOP_AssignmentDataSet1TableAdapters.Account_PasswordTableAdapter();
            this.accountDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.passwordDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iOOP_AssignmentDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.accountPasswordBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // addradioButton
            // 
            this.addradioButton.AutoSize = true;
            this.addradioButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addradioButton.Location = new System.Drawing.Point(168, 198);
            this.addradioButton.Name = "addradioButton";
            this.addradioButton.Size = new System.Drawing.Size(56, 24);
            this.addradioButton.TabIndex = 1;
            this.addradioButton.TabStop = true;
            this.addradioButton.Text = "Add";
            this.addradioButton.UseVisualStyleBackColor = true;
            this.addradioButton.CheckedChanged += new System.EventHandler(this.addradioButton_CheckedChanged);
            // 
            // deleteradioButton
            // 
            this.deleteradioButton.AutoSize = true;
            this.deleteradioButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deleteradioButton.Location = new System.Drawing.Point(259, 198);
            this.deleteradioButton.Name = "deleteradioButton";
            this.deleteradioButton.Size = new System.Drawing.Size(74, 24);
            this.deleteradioButton.TabIndex = 2;
            this.deleteradioButton.TabStop = true;
            this.deleteradioButton.Text = "Delete";
            this.deleteradioButton.UseVisualStyleBackColor = true;
            this.deleteradioButton.CheckedChanged += new System.EventHandler(this.deleteradioButton_CheckedChanged);
            // 
            // titlelabel
            // 
            this.titlelabel.AutoSize = true;
            this.titlelabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.titlelabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titlelabel.Location = new System.Drawing.Point(113, 243);
            this.titlelabel.Name = "titlelabel";
            this.titlelabel.Size = new System.Drawing.Size(312, 26);
            this.titlelabel.TabIndex = 3;
            this.titlelabel.Text = "Which account do you want to add?";
            // 
            // accounttextBox
            // 
            this.accounttextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.accounttextBox.Location = new System.Drawing.Point(213, 284);
            this.accounttextBox.Name = "accounttextBox";
            this.accounttextBox.Size = new System.Drawing.Size(148, 26);
            this.accounttextBox.TabIndex = 4;
            this.accounttextBox.TextChanged += new System.EventHandler(this.accounttextBox_TextChanged);
            // 
            // savebutton
            // 
            this.savebutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.savebutton.Location = new System.Drawing.Point(168, 387);
            this.savebutton.Name = "savebutton";
            this.savebutton.Size = new System.Drawing.Size(75, 27);
            this.savebutton.TabIndex = 5;
            this.savebutton.Text = "Save";
            this.savebutton.UseVisualStyleBackColor = true;
            this.savebutton.Click += new System.EventHandler(this.savebutton_Click);
            // 
            // cancelbutton
            // 
            this.cancelbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancelbutton.Location = new System.Drawing.Point(259, 387);
            this.cancelbutton.Name = "cancelbutton";
            this.cancelbutton.Size = new System.Drawing.Size(75, 27);
            this.cancelbutton.TabIndex = 6;
            this.cancelbutton.Text = "Cancel";
            this.cancelbutton.UseVisualStyleBackColor = true;
            this.cancelbutton.Click += new System.EventHandler(this.cancelbutton_Click);
            // 
            // passwordtextBox
            // 
            this.passwordtextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passwordtextBox.Location = new System.Drawing.Point(213, 326);
            this.passwordtextBox.Name = "passwordtextBox";
            this.passwordtextBox.Size = new System.Drawing.Size(148, 26);
            this.passwordtextBox.TabIndex = 7;
            this.passwordtextBox.TextChanged += new System.EventHandler(this.passwordtextBox_TextChanged);
            // 
            // accountlabel
            // 
            this.accountlabel.AutoSize = true;
            this.accountlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.accountlabel.Location = new System.Drawing.Point(131, 287);
            this.accountlabel.Name = "accountlabel";
            this.accountlabel.Size = new System.Drawing.Size(76, 20);
            this.accountlabel.TabIndex = 8;
            this.accountlabel.Text = "Account :";
            // 
            // passwordlabel
            // 
            this.passwordlabel.AutoSize = true;
            this.passwordlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passwordlabel.Location = new System.Drawing.Point(121, 329);
            this.passwordlabel.Name = "passwordlabel";
            this.passwordlabel.Size = new System.Drawing.Size(86, 20);
            this.passwordlabel.TabIndex = 9;
            this.passwordlabel.Text = "Password :";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.accountDataGridViewTextBoxColumn,
            this.passwordDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.accountPasswordBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(125, 24);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(240, 150);
            this.dataGridView1.TabIndex = 10;
            // 
            // iOOP_AssignmentDataSet1
            // 
            this.iOOP_AssignmentDataSet1.DataSetName = "IOOP_AssignmentDataSet1";
            this.iOOP_AssignmentDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // accountPasswordBindingSource
            // 
            this.accountPasswordBindingSource.DataMember = "Account_Password";
            this.accountPasswordBindingSource.DataSource = this.iOOP_AssignmentDataSet1;
            // 
            // account_PasswordTableAdapter
            // 
            this.account_PasswordTableAdapter.ClearBeforeFill = true;
            // 
            // accountDataGridViewTextBoxColumn
            // 
            this.accountDataGridViewTextBoxColumn.DataPropertyName = "Account";
            this.accountDataGridViewTextBoxColumn.HeaderText = "Account";
            this.accountDataGridViewTextBoxColumn.Name = "accountDataGridViewTextBoxColumn";
            // 
            // passwordDataGridViewTextBoxColumn
            // 
            this.passwordDataGridViewTextBoxColumn.DataPropertyName = "Password";
            this.passwordDataGridViewTextBoxColumn.HeaderText = "Password";
            this.passwordDataGridViewTextBoxColumn.Name = "passwordDataGridViewTextBoxColumn";
            // 
            // AddDelete_Staff
            // 
            this.ClientSize = new System.Drawing.Size(484, 461);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.passwordlabel);
            this.Controls.Add(this.accountlabel);
            this.Controls.Add(this.passwordtextBox);
            this.Controls.Add(this.cancelbutton);
            this.Controls.Add(this.savebutton);
            this.Controls.Add(this.accounttextBox);
            this.Controls.Add(this.titlelabel);
            this.Controls.Add(this.deleteradioButton);
            this.Controls.Add(this.addradioButton);
            this.Name = "AddDelete_Staff";
            this.Text = "Add/Delete Staff";
            this.Load += new System.EventHandler(this.AddDelete_Staff_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iOOP_AssignmentDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.accountPasswordBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void savebutton_Click(object sender, EventArgs e)
        {
            if(accounttextBox.Text == "admin")
            {
                MessageBox.Show("Can not delete administrator account");
                return;
            }
            string input_account, input_password;
            input_account = accounttextBox.Text;
            input_password = passwordtextBox.Text;
            if(accounttextBox.Text == "")
            {
                accountlabel.ForeColor = Color.Red;
            }
            if(passwordtextBox.Text  == "")
            {
                passwordlabel.ForeColor = Color.Red;
            }
            if(accounttextBox.Text  == "" || passwordtextBox.Text == "")
            {
                MessageBox.Show("Please complete the information.");
                return;
            }
            cmdSearch.CommandText = "Select * from Account_Password where Account = \'" + input_account + "\';";
            cmdSearch.Connection = cnnOLEDB;
            OleDbDataReader dr = cmdSearch.ExecuteReader();

            if (addradioButton.Checked)
            {
                if (dr.Read() == true)
                {
                    MessageBox.Show("You are not allowed to add the same account");
                    dr.Close();
                    return;
                }
                else
                {
                    cmdInsert.CommandText = "INSERT INTO Account_Password VALUES( ('" + accounttextBox.Text + "'),('" + passwordtextBox.Text + "'))";
                    cmdInsert.CommandType = CommandType.Text;
                    cmdInsert.Connection = cnnOLEDB;
                    cmdInsert.ExecuteNonQuery();
                    MessageBox.Show("Insertion Successful");
                    dr.Close();
                    return;
                }
            }
            if (deleteradioButton.Checked)
            {

                if (dr.Read() == true)
                {
                    cmdDelete.CommandText = "Delete from Account_Password where Account = \'" + accounttextBox.Text + "\';";
                    cmdDelete.CommandType = CommandType.Text;
                    cmdDelete.Connection = cnnOLEDB;
                    cmdDelete.ExecuteNonQuery();
                    MessageBox.Show("Deletion Successful");
                }
                else
                {
                    MessageBox.Show("This account is not in the list.");
                }
                dr.Close();
                return;
            }

        }
        private void AddDelete_Staff_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'iOOP_AssignmentDataSet1.Account_Password' table. You can move, or remove it, as needed.
            this.account_PasswordTableAdapter.Fill(this.iOOP_AssignmentDataSet1.Account_Password);
            cnnOLEDB.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=IOOP Assignment.mdb;";
            cnnOLEDB.Open();
        }

        private void deleteradioButton_CheckedChanged(object sender, EventArgs e)
        {
            passwordlabel.Hide();
            passwordtextBox.Hide();
            titlelabel.Text = "Which account do you want to delete?";
        }

        private void addradioButton_CheckedChanged(object sender, EventArgs e)
        {
            passwordlabel.Show();
            passwordtextBox.Show();
            titlelabel.Text = "Which account do you want to add?";
        }

        private void cancelbutton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void accounttextBox_TextChanged(object sender, EventArgs e)
        {
            if(accounttextBox.Text != "")
            {
                accountlabel.ForeColor = Color.Black;
            }
        }

        private void passwordtextBox_TextChanged(object sender, EventArgs e)
        {
            if (passwordtextBox.Text != "")
            {
                passwordlabel.ForeColor = Color.Black;
            }

        }
    }
}
