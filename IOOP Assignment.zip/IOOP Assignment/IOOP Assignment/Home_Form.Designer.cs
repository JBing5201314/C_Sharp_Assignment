﻿namespace IOOP_Assignment
{
    partial class Home_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.customerInformatiomgroupBox = new System.Windows.Forms.GroupBox();
            this.nametextBox = new System.Windows.Forms.TextBox();
            this.addresslabel = new System.Windows.Forms.Label();
            this.emailtextBox = new System.Windows.Forms.TextBox();
            this.emaillabel = new System.Windows.Forms.Label();
            this.addresstextBox = new System.Windows.Forms.TextBox();
            this.contactNolabel = new System.Windows.Forms.Label();
            this.contactNotextBox = new System.Windows.Forms.TextBox();
            this.namelabel = new System.Windows.Forms.Label();
            this.IcPassporttextBox = new System.Windows.Forms.TextBox();
            this.IcPassportlabel = new System.Windows.Forms.Label();
            this.bookinggroupBox = new System.Windows.Forms.GroupBox();
            this.checkOutdateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.checkIndateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.roomcomboBox = new System.Windows.Forms.ComboBox();
            this.roomlabel = new System.Windows.Forms.Label();
            this.hotelcomboBox = new System.Windows.Forms.ComboBox();
            this.hotellabel = new System.Windows.Forms.Label();
            this.holidayPackagescomboBox = new System.Windows.Forms.ComboBox();
            this.holidayPackageslabel = new System.Windows.Forms.Label();
            this.checkOutlabel = new System.Windows.Forms.Label();
            this.checkInlabel = new System.Windows.Forms.Label();
            this.functionsgroupBox = new System.Windows.Forms.GroupBox();
            this.logOutbutton = new System.Windows.Forms.Button();
            this.paymentbutton = new System.Windows.Forms.Button();
            this.generateReportbutton = new System.Windows.Forms.Button();
            this.newBookingbutton2 = new System.Windows.Forms.Button();
            this.newBookingbutton = new System.Windows.Forms.Button();
            this.addDeleteStaffbutton = new System.Windows.Forms.Button();
            this.cancelBookingbutton2 = new System.Windows.Forms.Button();
            this.cancelBookingbutton = new System.Windows.Forms.Button();
            this.changePasswordbutton = new System.Windows.Forms.Button();
            this.searchBookingbutton2 = new System.Windows.Forms.Button();
            this.searchBookingbutton = new System.Windows.Forms.Button();
            this.changePasswordgroupBox = new System.Windows.Forms.GroupBox();
            this.cancelPasswordbutton = new System.Windows.Forms.Button();
            this.savePasswordbutton = new System.Windows.Forms.Button();
            this.newPassword2textBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.newPasswordtextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.oldPasswordtextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.customerInformatiomgroupBox.SuspendLayout();
            this.bookinggroupBox.SuspendLayout();
            this.functionsgroupBox.SuspendLayout();
            this.changePasswordgroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // customerInformatiomgroupBox
            // 
            this.customerInformatiomgroupBox.Controls.Add(this.nametextBox);
            this.customerInformatiomgroupBox.Controls.Add(this.addresslabel);
            this.customerInformatiomgroupBox.Controls.Add(this.emailtextBox);
            this.customerInformatiomgroupBox.Controls.Add(this.emaillabel);
            this.customerInformatiomgroupBox.Controls.Add(this.addresstextBox);
            this.customerInformatiomgroupBox.Controls.Add(this.contactNolabel);
            this.customerInformatiomgroupBox.Controls.Add(this.contactNotextBox);
            this.customerInformatiomgroupBox.Controls.Add(this.namelabel);
            this.customerInformatiomgroupBox.Controls.Add(this.IcPassporttextBox);
            this.customerInformatiomgroupBox.Controls.Add(this.IcPassportlabel);
            this.customerInformatiomgroupBox.Location = new System.Drawing.Point(-1, 1);
            this.customerInformatiomgroupBox.Name = "customerInformatiomgroupBox";
            this.customerInformatiomgroupBox.Size = new System.Drawing.Size(623, 204);
            this.customerInformatiomgroupBox.TabIndex = 0;
            this.customerInformatiomgroupBox.TabStop = false;
            this.customerInformatiomgroupBox.Text = "Customer Information";
            this.customerInformatiomgroupBox.Visible = false;
            this.customerInformatiomgroupBox.Enter += new System.EventHandler(this.customerInformatiomgroupBox_Enter);
            // 
            // nametextBox
            // 
            this.nametextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nametextBox.Location = new System.Drawing.Point(386, 27);
            this.nametextBox.Name = "nametextBox";
            this.nametextBox.Size = new System.Drawing.Size(225, 26);
            this.nametextBox.TabIndex = 2;
            this.nametextBox.TextChanged += new System.EventHandler(this.textBox_TextChanged);
            // 
            // addresslabel
            // 
            this.addresslabel.AutoSize = true;
            this.addresslabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addresslabel.Location = new System.Drawing.Point(36, 167);
            this.addresslabel.Name = "addresslabel";
            this.addresslabel.Size = new System.Drawing.Size(76, 20);
            this.addresslabel.TabIndex = 0;
            this.addresslabel.Text = "Address :";
            // 
            // emailtextBox
            // 
            this.emailtextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emailtextBox.Location = new System.Drawing.Point(118, 116);
            this.emailtextBox.Name = "emailtextBox";
            this.emailtextBox.Size = new System.Drawing.Size(414, 26);
            this.emailtextBox.TabIndex = 4;
            this.emailtextBox.TextChanged += new System.EventHandler(this.textBox_TextChanged);
            // 
            // emaillabel
            // 
            this.emaillabel.AutoSize = true;
            this.emaillabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emaillabel.Location = new System.Drawing.Point(56, 121);
            this.emaillabel.Name = "emaillabel";
            this.emaillabel.Size = new System.Drawing.Size(56, 20);
            this.emaillabel.TabIndex = 0;
            this.emaillabel.Text = "Email :";
            // 
            // addresstextBox
            // 
            this.addresstextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addresstextBox.Location = new System.Drawing.Point(118, 164);
            this.addresstextBox.Name = "addresstextBox";
            this.addresstextBox.Size = new System.Drawing.Size(414, 26);
            this.addresstextBox.TabIndex = 5;
            this.addresstextBox.TextChanged += new System.EventHandler(this.textBox_TextChanged);
            // 
            // contactNolabel
            // 
            this.contactNolabel.AutoSize = true;
            this.contactNolabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contactNolabel.Location = new System.Drawing.Point(11, 74);
            this.contactNolabel.Name = "contactNolabel";
            this.contactNolabel.Size = new System.Drawing.Size(101, 20);
            this.contactNolabel.TabIndex = 0;
            this.contactNolabel.Text = "Contact No. :";
            // 
            // contactNotextBox
            // 
            this.contactNotextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contactNotextBox.Location = new System.Drawing.Point(118, 71);
            this.contactNotextBox.Name = "contactNotextBox";
            this.contactNotextBox.Size = new System.Drawing.Size(414, 26);
            this.contactNotextBox.TabIndex = 3;
            this.contactNotextBox.TextChanged += new System.EventHandler(this.textBox_TextChanged);
            // 
            // namelabel
            // 
            this.namelabel.AutoSize = true;
            this.namelabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.namelabel.Location = new System.Drawing.Point(324, 30);
            this.namelabel.Name = "namelabel";
            this.namelabel.Size = new System.Drawing.Size(59, 20);
            this.namelabel.TabIndex = 0;
            this.namelabel.Text = "Name :";
            // 
            // IcPassporttextBox
            // 
            this.IcPassporttextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IcPassporttextBox.Location = new System.Drawing.Point(118, 27);
            this.IcPassporttextBox.Name = "IcPassporttextBox";
            this.IcPassporttextBox.Size = new System.Drawing.Size(200, 26);
            this.IcPassporttextBox.TabIndex = 1;
            this.IcPassporttextBox.TextChanged += new System.EventHandler(this.textBox_TextChanged);
            // 
            // IcPassportlabel
            // 
            this.IcPassportlabel.AutoSize = true;
            this.IcPassportlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IcPassportlabel.Location = new System.Drawing.Point(12, 30);
            this.IcPassportlabel.Name = "IcPassportlabel";
            this.IcPassportlabel.Size = new System.Drawing.Size(100, 20);
            this.IcPassportlabel.TabIndex = 0;
            this.IcPassportlabel.Text = "IC/Passport :";
            // 
            // bookinggroupBox
            // 
            this.bookinggroupBox.Controls.Add(this.checkOutdateTimePicker);
            this.bookinggroupBox.Controls.Add(this.checkIndateTimePicker);
            this.bookinggroupBox.Controls.Add(this.roomcomboBox);
            this.bookinggroupBox.Controls.Add(this.roomlabel);
            this.bookinggroupBox.Controls.Add(this.hotelcomboBox);
            this.bookinggroupBox.Controls.Add(this.hotellabel);
            this.bookinggroupBox.Controls.Add(this.holidayPackagescomboBox);
            this.bookinggroupBox.Controls.Add(this.holidayPackageslabel);
            this.bookinggroupBox.Controls.Add(this.checkOutlabel);
            this.bookinggroupBox.Controls.Add(this.checkInlabel);
            this.bookinggroupBox.Location = new System.Drawing.Point(0, 205);
            this.bookinggroupBox.Name = "bookinggroupBox";
            this.bookinggroupBox.Size = new System.Drawing.Size(623, 143);
            this.bookinggroupBox.TabIndex = 0;
            this.bookinggroupBox.TabStop = false;
            this.bookinggroupBox.Text = "Booking";
            this.bookinggroupBox.Visible = false;
            // 
            // checkOutdateTimePicker
            // 
            this.checkOutdateTimePicker.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkOutdateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.checkOutdateTimePicker.Location = new System.Drawing.Point(379, 107);
            this.checkOutdateTimePicker.Name = "checkOutdateTimePicker";
            this.checkOutdateTimePicker.Size = new System.Drawing.Size(188, 26);
            this.checkOutdateTimePicker.TabIndex = 35;
            // 
            // checkIndateTimePicker
            // 
            this.checkIndateTimePicker.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkIndateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.checkIndateTimePicker.Location = new System.Drawing.Point(96, 107);
            this.checkIndateTimePicker.Name = "checkIndateTimePicker";
            this.checkIndateTimePicker.Size = new System.Drawing.Size(188, 26);
            this.checkIndateTimePicker.TabIndex = 34;
            this.checkIndateTimePicker.ValueChanged += new System.EventHandler(this.checkIndateTimePicker_ValueChanged);
            // 
            // roomcomboBox
            // 
            this.roomcomboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.roomcomboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.roomcomboBox.FormattingEnabled = true;
            this.roomcomboBox.Location = new System.Drawing.Point(356, 64);
            this.roomcomboBox.Name = "roomcomboBox";
            this.roomcomboBox.Size = new System.Drawing.Size(211, 28);
            this.roomcomboBox.TabIndex = 3;
            this.roomcomboBox.SelectedIndexChanged += new System.EventHandler(this.roomcomboBox_SelectedIndexChanged);
            // 
            // roomlabel
            // 
            this.roomlabel.AutoSize = true;
            this.roomlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.roomlabel.Location = new System.Drawing.Point(290, 67);
            this.roomlabel.Name = "roomlabel";
            this.roomlabel.Size = new System.Drawing.Size(60, 20);
            this.roomlabel.TabIndex = 33;
            this.roomlabel.Text = "Room :";
            // 
            // hotelcomboBox
            // 
            this.hotelcomboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.hotelcomboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hotelcomboBox.FormattingEnabled = true;
            this.hotelcomboBox.Location = new System.Drawing.Point(73, 63);
            this.hotelcomboBox.Name = "hotelcomboBox";
            this.hotelcomboBox.Size = new System.Drawing.Size(211, 28);
            this.hotelcomboBox.TabIndex = 2;
            this.hotelcomboBox.SelectedIndexChanged += new System.EventHandler(this.hotelcomboBox_SelectedIndexChanged);
            // 
            // hotellabel
            // 
            this.hotellabel.AutoSize = true;
            this.hotellabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hotellabel.Location = new System.Drawing.Point(12, 67);
            this.hotellabel.Name = "hotellabel";
            this.hotellabel.Size = new System.Drawing.Size(55, 20);
            this.hotellabel.TabIndex = 31;
            this.hotellabel.Text = "Hotel :";
            // 
            // holidayPackagescomboBox
            // 
            this.holidayPackagescomboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.holidayPackagescomboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.holidayPackagescomboBox.FormattingEnabled = true;
            this.holidayPackagescomboBox.Location = new System.Drawing.Point(161, 17);
            this.holidayPackagescomboBox.Name = "holidayPackagescomboBox";
            this.holidayPackagescomboBox.Size = new System.Drawing.Size(384, 28);
            this.holidayPackagescomboBox.TabIndex = 1;
            this.holidayPackagescomboBox.SelectedIndexChanged += new System.EventHandler(this.holidayPackagescomboBox_SelectedIndexChanged);
            // 
            // holidayPackageslabel
            // 
            this.holidayPackageslabel.AutoSize = true;
            this.holidayPackageslabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.holidayPackageslabel.Location = new System.Drawing.Point(12, 20);
            this.holidayPackageslabel.Name = "holidayPackageslabel";
            this.holidayPackageslabel.Size = new System.Drawing.Size(143, 20);
            this.holidayPackageslabel.TabIndex = 29;
            this.holidayPackageslabel.Text = "Holiday Packages :";
            // 
            // checkOutlabel
            // 
            this.checkOutlabel.AutoSize = true;
            this.checkOutlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkOutlabel.Location = new System.Drawing.Point(290, 112);
            this.checkOutlabel.Name = "checkOutlabel";
            this.checkOutlabel.Size = new System.Drawing.Size(89, 20);
            this.checkOutlabel.TabIndex = 28;
            this.checkOutlabel.Text = "Check out :";
            // 
            // checkInlabel
            // 
            this.checkInlabel.AutoSize = true;
            this.checkInlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkInlabel.Location = new System.Drawing.Point(12, 112);
            this.checkInlabel.Name = "checkInlabel";
            this.checkInlabel.Size = new System.Drawing.Size(78, 20);
            this.checkInlabel.TabIndex = 25;
            this.checkInlabel.Text = "Check in :";
            // 
            // functionsgroupBox
            // 
            this.functionsgroupBox.Controls.Add(this.logOutbutton);
            this.functionsgroupBox.Controls.Add(this.paymentbutton);
            this.functionsgroupBox.Controls.Add(this.generateReportbutton);
            this.functionsgroupBox.Controls.Add(this.newBookingbutton2);
            this.functionsgroupBox.Controls.Add(this.newBookingbutton);
            this.functionsgroupBox.Controls.Add(this.addDeleteStaffbutton);
            this.functionsgroupBox.Controls.Add(this.cancelBookingbutton2);
            this.functionsgroupBox.Controls.Add(this.cancelBookingbutton);
            this.functionsgroupBox.Controls.Add(this.changePasswordbutton);
            this.functionsgroupBox.Controls.Add(this.searchBookingbutton2);
            this.functionsgroupBox.Controls.Add(this.searchBookingbutton);
            this.functionsgroupBox.Location = new System.Drawing.Point(629, -1);
            this.functionsgroupBox.Name = "functionsgroupBox";
            this.functionsgroupBox.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.functionsgroupBox.Size = new System.Drawing.Size(151, 464);
            this.functionsgroupBox.TabIndex = 0;
            this.functionsgroupBox.TabStop = false;
            this.functionsgroupBox.Text = "Functions";
            // 
            // logOutbutton
            // 
            this.logOutbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logOutbutton.Location = new System.Drawing.Point(6, 369);
            this.logOutbutton.Name = "logOutbutton";
            this.logOutbutton.Size = new System.Drawing.Size(141, 45);
            this.logOutbutton.TabIndex = 23;
            this.logOutbutton.Text = "Log Out";
            this.logOutbutton.UseVisualStyleBackColor = true;
            this.logOutbutton.Click += new System.EventHandler(this.logOutbutton_Click);
            // 
            // paymentbutton
            // 
            this.paymentbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.paymentbutton.Location = new System.Drawing.Point(5, 219);
            this.paymentbutton.Name = "paymentbutton";
            this.paymentbutton.Size = new System.Drawing.Size(141, 45);
            this.paymentbutton.TabIndex = 20;
            this.paymentbutton.Text = "Payment";
            this.paymentbutton.UseVisualStyleBackColor = true;
            this.paymentbutton.Click += new System.EventHandler(this.paymentbutton_Click);
            // 
            // generateReportbutton
            // 
            this.generateReportbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.generateReportbutton.Location = new System.Drawing.Point(6, 319);
            this.generateReportbutton.Name = "generateReportbutton";
            this.generateReportbutton.Size = new System.Drawing.Size(141, 45);
            this.generateReportbutton.TabIndex = 22;
            this.generateReportbutton.Text = "Generate Report";
            this.generateReportbutton.UseVisualStyleBackColor = true;
            this.generateReportbutton.Visible = false;
            this.generateReportbutton.Click += new System.EventHandler(this.generateReportbutton_Click);
            // 
            // newBookingbutton2
            // 
            this.newBookingbutton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.newBookingbutton2.Location = new System.Drawing.Point(6, 16);
            this.newBookingbutton2.Name = "newBookingbutton2";
            this.newBookingbutton2.Size = new System.Drawing.Size(141, 45);
            this.newBookingbutton2.TabIndex = 15;
            this.newBookingbutton2.Text = "New Booking";
            this.newBookingbutton2.UseVisualStyleBackColor = true;
            this.newBookingbutton2.Click += new System.EventHandler(this.newBookingbutton2_Click);
            // 
            // newBookingbutton
            // 
            this.newBookingbutton.BackColor = System.Drawing.Color.Gray;
            this.newBookingbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.newBookingbutton.Location = new System.Drawing.Point(5, 16);
            this.newBookingbutton.Name = "newBookingbutton";
            this.newBookingbutton.Size = new System.Drawing.Size(141, 45);
            this.newBookingbutton.TabIndex = 15;
            this.newBookingbutton.Text = "New Booking";
            this.newBookingbutton.UseVisualStyleBackColor = false;
            this.newBookingbutton.Visible = false;
            this.newBookingbutton.Click += new System.EventHandler(this.newBookingbutton_Click);
            // 
            // addDeleteStaffbutton
            // 
            this.addDeleteStaffbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addDeleteStaffbutton.Location = new System.Drawing.Point(6, 269);
            this.addDeleteStaffbutton.Name = "addDeleteStaffbutton";
            this.addDeleteStaffbutton.Size = new System.Drawing.Size(141, 45);
            this.addDeleteStaffbutton.TabIndex = 21;
            this.addDeleteStaffbutton.Text = "Add/Delete Staff";
            this.addDeleteStaffbutton.UseVisualStyleBackColor = true;
            this.addDeleteStaffbutton.Visible = false;
            this.addDeleteStaffbutton.Click += new System.EventHandler(this.addDeleteStaffbutton_Click);
            // 
            // cancelBookingbutton2
            // 
            this.cancelBookingbutton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancelBookingbutton2.Location = new System.Drawing.Point(6, 65);
            this.cancelBookingbutton2.Name = "cancelBookingbutton2";
            this.cancelBookingbutton2.Size = new System.Drawing.Size(141, 45);
            this.cancelBookingbutton2.TabIndex = 16;
            this.cancelBookingbutton2.Text = "Cancel Booking";
            this.cancelBookingbutton2.UseVisualStyleBackColor = true;
            this.cancelBookingbutton2.Click += new System.EventHandler(this.cancelBookingbutton2_Click);
            // 
            // cancelBookingbutton
            // 
            this.cancelBookingbutton.BackColor = System.Drawing.Color.Gray;
            this.cancelBookingbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancelBookingbutton.Location = new System.Drawing.Point(6, 65);
            this.cancelBookingbutton.Name = "cancelBookingbutton";
            this.cancelBookingbutton.Size = new System.Drawing.Size(141, 45);
            this.cancelBookingbutton.TabIndex = 16;
            this.cancelBookingbutton.Text = "Cancel Booking";
            this.cancelBookingbutton.UseVisualStyleBackColor = false;
            this.cancelBookingbutton.Visible = false;
            this.cancelBookingbutton.Click += new System.EventHandler(this.cancelBookingbutton_Click);
            // 
            // changePasswordbutton
            // 
            this.changePasswordbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.changePasswordbutton.Location = new System.Drawing.Point(6, 169);
            this.changePasswordbutton.Name = "changePasswordbutton";
            this.changePasswordbutton.Size = new System.Drawing.Size(141, 45);
            this.changePasswordbutton.TabIndex = 19;
            this.changePasswordbutton.Text = "Change Password";
            this.changePasswordbutton.UseVisualStyleBackColor = true;
            this.changePasswordbutton.Click += new System.EventHandler(this.changePasswordbutton_Click);
            // 
            // searchBookingbutton2
            // 
            this.searchBookingbutton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchBookingbutton2.Location = new System.Drawing.Point(5, 116);
            this.searchBookingbutton2.Name = "searchBookingbutton2";
            this.searchBookingbutton2.Size = new System.Drawing.Size(141, 45);
            this.searchBookingbutton2.TabIndex = 17;
            this.searchBookingbutton2.Text = "Search Booking";
            this.searchBookingbutton2.UseVisualStyleBackColor = true;
            this.searchBookingbutton2.Click += new System.EventHandler(this.searchBookingbutton2_Click);
            // 
            // searchBookingbutton
            // 
            this.searchBookingbutton.BackColor = System.Drawing.Color.Gray;
            this.searchBookingbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchBookingbutton.Location = new System.Drawing.Point(5, 116);
            this.searchBookingbutton.Name = "searchBookingbutton";
            this.searchBookingbutton.Size = new System.Drawing.Size(141, 45);
            this.searchBookingbutton.TabIndex = 17;
            this.searchBookingbutton.Text = "Search Booking";
            this.searchBookingbutton.UseVisualStyleBackColor = false;
            this.searchBookingbutton.Visible = false;
            this.searchBookingbutton.Click += new System.EventHandler(this.searchBookingbutton_Click);
            // 
            // changePasswordgroupBox
            // 
            this.changePasswordgroupBox.Controls.Add(this.cancelPasswordbutton);
            this.changePasswordgroupBox.Controls.Add(this.savePasswordbutton);
            this.changePasswordgroupBox.Controls.Add(this.newPassword2textBox);
            this.changePasswordgroupBox.Controls.Add(this.label3);
            this.changePasswordgroupBox.Controls.Add(this.newPasswordtextBox);
            this.changePasswordgroupBox.Controls.Add(this.label2);
            this.changePasswordgroupBox.Controls.Add(this.oldPasswordtextBox);
            this.changePasswordgroupBox.Controls.Add(this.label1);
            this.changePasswordgroupBox.Location = new System.Drawing.Point(0, 348);
            this.changePasswordgroupBox.Name = "changePasswordgroupBox";
            this.changePasswordgroupBox.Size = new System.Drawing.Size(623, 122);
            this.changePasswordgroupBox.TabIndex = 19;
            this.changePasswordgroupBox.TabStop = false;
            this.changePasswordgroupBox.Text = "Change Password";
            this.changePasswordgroupBox.Visible = false;
            // 
            // cancelPasswordbutton
            // 
            this.cancelPasswordbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancelPasswordbutton.Location = new System.Drawing.Point(519, 79);
            this.cancelPasswordbutton.Name = "cancelPasswordbutton";
            this.cancelPasswordbutton.Size = new System.Drawing.Size(94, 33);
            this.cancelPasswordbutton.TabIndex = 20;
            this.cancelPasswordbutton.Text = "Cancel";
            this.cancelPasswordbutton.UseVisualStyleBackColor = true;
            this.cancelPasswordbutton.Click += new System.EventHandler(this.cancelPasswordbutton_Click);
            // 
            // savePasswordbutton
            // 
            this.savePasswordbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.savePasswordbutton.Location = new System.Drawing.Point(419, 79);
            this.savePasswordbutton.Name = "savePasswordbutton";
            this.savePasswordbutton.Size = new System.Drawing.Size(94, 33);
            this.savePasswordbutton.TabIndex = 19;
            this.savePasswordbutton.Text = "Save";
            this.savePasswordbutton.UseVisualStyleBackColor = true;
            this.savePasswordbutton.Click += new System.EventHandler(this.savePasswordbutton_Click);
            // 
            // newPassword2textBox
            // 
            this.newPassword2textBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.newPassword2textBox.Location = new System.Drawing.Point(161, 88);
            this.newPassword2textBox.Name = "newPassword2textBox";
            this.newPassword2textBox.Size = new System.Drawing.Size(200, 26);
            this.newPassword2textBox.TabIndex = 7;
            this.newPassword2textBox.UseSystemPasswordChar = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(49, 91);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(101, 20);
            this.label3.TabIndex = 6;
            this.label3.Text = "Enter Again :";
            // 
            // newPasswordtextBox
            // 
            this.newPasswordtextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.newPasswordtextBox.Location = new System.Drawing.Point(161, 56);
            this.newPasswordtextBox.Name = "newPasswordtextBox";
            this.newPasswordtextBox.Size = new System.Drawing.Size(200, 26);
            this.newPasswordtextBox.TabIndex = 5;
            this.newPasswordtextBox.UseSystemPasswordChar = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(29, 59);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(121, 20);
            this.label2.TabIndex = 4;
            this.label2.Text = "New Password :";
            // 
            // oldPasswordtextBox
            // 
            this.oldPasswordtextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.oldPasswordtextBox.Location = new System.Drawing.Point(161, 23);
            this.oldPasswordtextBox.Name = "oldPasswordtextBox";
            this.oldPasswordtextBox.Size = new System.Drawing.Size(200, 26);
            this.oldPasswordtextBox.TabIndex = 3;
            this.oldPasswordtextBox.UseSystemPasswordChar = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(36, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "Old Password :";
            // 
            // Home_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 468);
            this.Controls.Add(this.changePasswordgroupBox);
            this.Controls.Add(this.customerInformatiomgroupBox);
            this.Controls.Add(this.functionsgroupBox);
            this.Controls.Add(this.bookinggroupBox);
            this.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "Home_Form";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Pacific Reservation System";
            this.Load += new System.EventHandler(this.Home_Form_Load);
            this.customerInformatiomgroupBox.ResumeLayout(false);
            this.customerInformatiomgroupBox.PerformLayout();
            this.bookinggroupBox.ResumeLayout(false);
            this.bookinggroupBox.PerformLayout();
            this.functionsgroupBox.ResumeLayout(false);
            this.changePasswordgroupBox.ResumeLayout(false);
            this.changePasswordgroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox customerInformatiomgroupBox;
        private System.Windows.Forms.TextBox nametextBox;
        private System.Windows.Forms.Label addresslabel;
        private System.Windows.Forms.TextBox emailtextBox;
        private System.Windows.Forms.Label emaillabel;
        private System.Windows.Forms.TextBox addresstextBox;
        private System.Windows.Forms.Label contactNolabel;
        private System.Windows.Forms.TextBox contactNotextBox;
        private System.Windows.Forms.Label namelabel;
        private System.Windows.Forms.TextBox IcPassporttextBox;
        private System.Windows.Forms.Label IcPassportlabel;
        private System.Windows.Forms.GroupBox bookinggroupBox;
        private System.Windows.Forms.ComboBox roomcomboBox;
        private System.Windows.Forms.Label roomlabel;
        private System.Windows.Forms.ComboBox hotelcomboBox;
        private System.Windows.Forms.Label hotellabel;
        private System.Windows.Forms.ComboBox holidayPackagescomboBox;
        private System.Windows.Forms.Label holidayPackageslabel;
        private System.Windows.Forms.Label checkOutlabel;
        private System.Windows.Forms.Label checkInlabel;
        private System.Windows.Forms.DateTimePicker checkIndateTimePicker;
        private System.Windows.Forms.DateTimePicker checkOutdateTimePicker;
        private System.Windows.Forms.GroupBox functionsgroupBox;
        private System.Windows.Forms.Button paymentbutton;
        private System.Windows.Forms.Button generateReportbutton;
        private System.Windows.Forms.Button newBookingbutton2;
        private System.Windows.Forms.Button newBookingbutton;
        private System.Windows.Forms.Button addDeleteStaffbutton;
        private System.Windows.Forms.Button cancelBookingbutton2;
        private System.Windows.Forms.Button cancelBookingbutton;
        private System.Windows.Forms.Button changePasswordbutton;
        private System.Windows.Forms.Button searchBookingbutton2;
        private System.Windows.Forms.Button searchBookingbutton;
        private System.Windows.Forms.Button logOutbutton;
        private System.Windows.Forms.GroupBox changePasswordgroupBox;
        private System.Windows.Forms.Button cancelPasswordbutton;
        private System.Windows.Forms.Button savePasswordbutton;
        private System.Windows.Forms.TextBox newPassword2textBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox newPasswordtextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox oldPasswordtextBox;
        private System.Windows.Forms.Label label1;
    }
}