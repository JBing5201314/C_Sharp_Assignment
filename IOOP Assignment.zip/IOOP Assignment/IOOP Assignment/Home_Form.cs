﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;


namespace IOOP_Assignment
{
    public partial class Home_Form : Form
    {
        public Home_Form()
        {
            InitializeComponent();
        }
        OleDbConnection cnnOLEDB = new OleDbConnection();
        OleDbCommand cmdSearch = new OleDbCommand();
        OleDbCommand cmdInsert = new OleDbCommand();
        OleDbCommand cmdDelete = new OleDbCommand();
        OleDbCommand cmdUpdate = new OleDbCommand();

        string account = Login_Form.account;
        public int holidayPackage_price, room_price;

        private void Home_Form_Load(object sender, EventArgs e)
        {
            //string account = Login_Form.account;
            this.Text = "Pacific Reservation System"+"   "+ "[Current login account : " + account +"]    "+ "[Login time : "+ DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"+"]");
            cnnOLEDB.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=IOOP Assignment.mdb;";
            cnnOLEDB.Open();
            checkIndateTimePicker.MinDate = DateTime.Now;
            holidayPackagescomboBox.Items.Add("Langkawi Island Tour (4 days 3 nights)");
            holidayPackagescomboBox.Items.Add("Cameron Highlands Tour (3 days 2 nights)");
            holidayPackagescomboBox.Items.Add("Tioman Island Tour (5 days 4 nights)");
            holidayPackagescomboBox.Items.Add("None");
            //newBookingbutton.Select();
            if(account == "admin")
            {
                addDeleteStaffbutton.Show();
                generateReportbutton.Show();
            }
            else
            {
                logOutbutton.Location=new Point(5, 316);
                Home_Form home_form = new Home_Form();
            }
        }

        private void holidayPackagescomboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            hotelcomboBox.SelectedIndex = -1;
            roomcomboBox.SelectedIndex = -1;
            roomcomboBox.Items.Clear();
            if (holidayPackagescomboBox.SelectedIndex == 0)
            {
                hotelcomboBox.Items.Clear();
                hotelcomboBox.Items.Add("Berjaya Langkawi Resort");
                hotelcomboBox.Items.Add("Adya Hotel Langkawi");
                holidayPackage_price = 1200;

            }
            else if (holidayPackagescomboBox.SelectedIndex == 1)
            {
                hotelcomboBox.Items.Clear();
                hotelcomboBox.Items.Add("Cameron Highlands Resort");
                hotelcomboBox.Items.Add("Century Pines Resort");
                holidayPackage_price = 800;
            }
            else if (holidayPackagescomboBox.SelectedIndex == 2)
            {
                hotelcomboBox.Items.Clear();
                hotelcomboBox.Items.Add("Tunamaya Beach & Spa Resort");
                hotelcomboBox.Items.Add("Berjaya Tioman Resort");
                holidayPackage_price = 1000;
            }
            else
            {
                hotelcomboBox.Items.Clear();
                hotelcomboBox.Items.Add("Cameron Highlands Resort");
                hotelcomboBox.Items.Add("Century Pines Resort");
                hotelcomboBox.Items.Add("Berjaya Langkawi Resort");
                hotelcomboBox.Items.Add("Adya Hotel Langkawi");
                hotelcomboBox.Items.Add("Tunamaya Beach & Spa Resort");
                hotelcomboBox.Items.Add("Berjaya Tioman Resort"); 
                holidayPackage_price = 0;
            }

            if (holidayPackagescomboBox.SelectedIndex != -1)
            {
                holidayPackageslabel.ForeColor = Color.Black;
            }
        }

        private void hotelcomboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            roomcomboBox.SelectedIndex = -1;
            roomcomboBox.Items.Clear();
            roomcomboBox.Items.Add("Single");
            roomcomboBox.Items.Add("Double Bed");
            roomcomboBox.Items.Add("Family Suite");

            if ((holidayPackagescomboBox.SelectedIndex == 1 && hotelcomboBox.SelectedIndex == 1) || (holidayPackagescomboBox.SelectedIndex == 3 && hotelcomboBox.SelectedIndex == 1))
            {
                roomcomboBox.Items.Clear();
                roomcomboBox.Items.Add("Single");
                roomcomboBox.Items.Add("Double Bed");
            }
            if (hotelcomboBox.SelectedIndex != -1)
            {
                hotellabel.ForeColor = Color.Black;
            }
        }

        private void textBox_TextChanged(object sender, EventArgs e)
        {
            if (IcPassporttextBox.Text != "")
            {
                IcPassportlabel.ForeColor = Color.Black;
            }
            if (nametextBox.Text != "")
            {
                namelabel.ForeColor = Color.Black;
            }
            if (contactNotextBox.Text != "")
            {
                contactNolabel.ForeColor = Color.Black;
            }
            if (emailtextBox.Text != "")
            {
                emaillabel.ForeColor = Color.Black;
            }
            if (addresstextBox.Text != "")
            {
                addresslabel.ForeColor = Color.Black;
            }
        }

        private void roomcomboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (roomcomboBox.SelectedIndex != -1)
            {
                roomlabel.ForeColor = Color.Black;
            }
        }

        private void checkInTimePicker_ValueChanged(object sender, EventArgs e)
        {
            checkIndateTimePicker.CustomFormat = "dd/MM/yyyy";
            checkOutdateTimePicker.MinDate = checkIndateTimePicker.Value.AddDays(1);
            checkOutdateTimePicker.Value = checkOutdateTimePicker.MinDate;
        }

        private void checkOutTimePicker_ValueChanged(object sender, EventArgs e)
        {
            checkOutdateTimePicker.CustomFormat = "dd/MM/yyyy";
        }


        private void searchbutton_Click(object sender, EventArgs e)
        {
            contactNotextBox.Enabled = false;
            emailtextBox.Enabled = false;
            addresstextBox.Enabled = false;
            holidayPackagescomboBox.Enabled = false;
            hotelcomboBox.Enabled = false;
            roomcomboBox.Enabled = false;
            checkIndateTimePicker.Enabled = false;
            checkOutdateTimePicker.Enabled = false;

            if (IcPassporttextBox.Text == "")
            {
                IcPassportlabel.ForeColor = Color.Red;
            }
            if (nametextBox.Text == "")
            {
                namelabel.ForeColor = Color.Red;
            }
            contactNolabel.ForeColor = Color.Black;
            emaillabel.ForeColor = Color.Black;
            addresslabel.ForeColor = Color.Black;
            holidayPackageslabel.ForeColor = Color.Black;
            hotellabel.ForeColor = Color.Black;
            roomlabel.ForeColor = Color.Black;
            if (IcPassporttextBox.Text == "" || nametextBox.Text == "")
            {
                MessageBox.Show("Please complete the information.");
                return;
            }
            if(IcPassporttextBox.Text != "")
            {
                cmdSearch.CommandText = "Select * from Customer_Information where IC_Passport = \'" + IcPassporttextBox.Text + "\' ;";
            }
            else
            {
                cmdSearch.CommandText = "Select * from Customer_Information where Name = \'" + nametextBox.Text + "\' ;";
            }

            cmdSearch.Connection = cnnOLEDB;
            OleDbDataReader dr = cmdSearch.ExecuteReader();
            if (dr.Read() == true)
            {

                if (IcPassporttextBox.Text  != dr[0].ToString()|| nametextBox.Text != dr[1].ToString())
                {
                    contactNotextBox.Clear();
                    emailtextBox.Clear();
                    addresstextBox.Clear();
                    holidayPackagescomboBox.SelectedIndex = -1;
                    hotelcomboBox.SelectedIndex = -1;
                    roomcomboBox.SelectedIndex = -1;

                    
                    MessageBox.Show("Customer information not found.");
                }
                else
                {
                    IcPassporttextBox.Text = dr[0].ToString();
                    nametextBox.Text = dr[1].ToString();
                    contactNotextBox.Text = dr[2].ToString();
                    emailtextBox.Text = dr[3].ToString();
                    addresstextBox.Text = dr[4].ToString();
                    holidayPackagescomboBox.Text = dr[5].ToString();
                    hotelcomboBox.Text = dr[6].ToString();
                    roomcomboBox.Text = dr[7].ToString();
                    checkIndateTimePicker.MinDate = new DateTime(1985, 6, 20);
                    checkOutdateTimePicker.MinDate = new DateTime(1985, 6, 20);
                    checkIndateTimePicker.Text = dr[8].ToString();
                    checkOutdateTimePicker.Text = dr[9].ToString();
                }
            }
            else
            {
                contactNotextBox.Clear();
                emailtextBox.Clear();
                addresstextBox.Clear();
                holidayPackagescomboBox.SelectedIndex = -1;
                hotelcomboBox.SelectedIndex = -1;
                roomcomboBox.SelectedIndex = -1;
                MessageBox.Show("Customer information not found.");

            }
            dr.Close();
            return;

        }

        private void checkIndateTimePicker_ValueChanged(object sender, EventArgs e)
        {
            checkOutdateTimePicker.MinDate = checkIndateTimePicker.Value.AddDays(1);
            checkOutdateTimePicker.Value = checkOutdateTimePicker.MinDate;

        }

        private void newBookingbutton2_Click(object sender, EventArgs e)
        {
            newBookingbutton2.Show();
            cancelBookingbutton2.Show();
            searchBookingbutton2.Show();
            changePasswordbutton.Show();




            customerInformatiomgroupBox.Show();
            bookinggroupBox.Show();
            IcPassporttextBox.Enabled = true; IcPassporttextBox.Clear();
            nametextBox.Enabled = true; nametextBox.Clear();
            contactNotextBox.Enabled = true; contactNotextBox.Clear();
            emailtextBox.Enabled = true; emailtextBox.Clear();
            addresstextBox.Enabled = true; addresstextBox.Clear();
            holidayPackagescomboBox.Enabled = true; holidayPackagescomboBox.SelectedIndex = -1;
            hotelcomboBox.Enabled = true; hotelcomboBox.SelectedIndex = -1;
            roomcomboBox.Enabled = true; roomcomboBox.SelectedIndex = -1;
            checkIndateTimePicker.Enabled = true;
            checkOutdateTimePicker.Enabled = true;
            newBookingbutton2.Hide();
            newBookingbutton.Show();
        }

        private void cancelBookingbutton2_Click(object sender, EventArgs e)
        {
            newBookingbutton2.Show();
            cancelBookingbutton2.Show();
            searchBookingbutton.Show();
            changePasswordbutton.Show();



            newBookingbutton2.Show();
            newBookingbutton.Hide();
            searchBookingbutton2.Show();
            searchBookingbutton.Hide();
            customerInformatiomgroupBox.Show();
            bookinggroupBox.Show();
            IcPassporttextBox.Enabled = true; IcPassporttextBox.Clear();IcPassportlabel.ForeColor = Color.Black;
            nametextBox.Enabled = true; nametextBox.Clear();namelabel.ForeColor = Color.Black;
            contactNotextBox.Enabled = false; contactNotextBox.Clear(); contactNolabel.ForeColor = Color.Black;
            emailtextBox.Enabled = false; emailtextBox.Clear();emaillabel.ForeColor = Color.Black;
            addresstextBox.Enabled = false; addresstextBox.Clear();addresslabel.ForeColor = Color.Black;
            holidayPackagescomboBox.Enabled = false; holidayPackagescomboBox.SelectedIndex = -1;holidayPackageslabel.ForeColor = Color.Black;
            hotelcomboBox.Enabled = false; hotelcomboBox.SelectedIndex = -1;hotellabel.ForeColor = Color.Black;
            roomcomboBox.Enabled = false; roomcomboBox.SelectedIndex = -1;roomlabel.ForeColor = Color.Black;
            checkIndateTimePicker.Enabled = false;
            checkOutdateTimePicker.Enabled = false;
            cancelBookingbutton2.Hide();
            cancelBookingbutton.Show();
        }

        private void cancelBookingbutton_Click(object sender, EventArgs e)
        {
            if (IcPassporttextBox.Text == "")
            {
                IcPassportlabel.ForeColor = Color.Red;
            }
            if (nametextBox.Text == "")
            {
                namelabel.ForeColor = Color.Red;
            } 
            if (IcPassporttextBox.Text == "" || nametextBox.Text == "")
            {
                MessageBox.Show("Please complete the information.");
                return;
            }
            string input_icPassport = IcPassporttextBox.Text, input_name = nametextBox.Text;
            string saved_icpassport, saved_name;
            cmdSearch.CommandText = "Select * from Customer_Information where IC_Passport = \'" + IcPassporttextBox.Text + "\' and Name = \'" + nametextBox.Text + "\' ;";
            cmdSearch.Connection = cnnOLEDB;
            OleDbDataReader dr = cmdSearch.ExecuteReader();
            if (dr.Read() == true)
            {
                saved_icpassport = dr[0].ToString();
                saved_name = dr[1].ToString();
                if (input_icPassport == saved_icpassport && input_name == saved_name)
                {
                    contactNotextBox.Text = dr[2].ToString();
                    emailtextBox.Text = dr[3].ToString();
                    addresstextBox.Text = dr[4].ToString();
                    holidayPackagescomboBox.Text = dr[5].ToString();
                    hotelcomboBox.Text = dr[6].ToString();
                    roomcomboBox.Text = dr[7].ToString();
                    checkIndateTimePicker.MinDate = new DateTime(1985, 6, 20);
                    checkOutdateTimePicker.MinDate = new DateTime(1985, 6, 20);
                    checkIndateTimePicker.Text = dr[8].ToString();
                    checkOutdateTimePicker.Text = dr[9].ToString();
                    if (MessageBox.Show("Are you sure you want to delete it？  \n\r\n\rClick 'OK' to delete", "System Prompt", MessageBoxButtons.OKCancel, MessageBoxIcon.Information) == DialogResult.OK)
                    {
                        cmdDelete.CommandText = "Delete from Customer_Information where IC_Passport = \'" + IcPassporttextBox.Text + "\';";
                        cmdDelete.CommandType = CommandType.Text;
                        cmdDelete.Connection = cnnOLEDB;
                        cmdDelete.ExecuteNonQuery();
                        MessageBox.Show("Deletion Successful"); 
                    }
                    dr.Close();
                    return;
                }
                else
                {
                    MessageBox.Show("Please check your information.");
                    dr.Close();
                    return;
                }
            }
            else
            {
                MessageBox.Show("Please check your information.");
            }
            dr.Close();
            return;
        }

        private void searchBookingbutton2_Click(object sender, EventArgs e)
        {
            newBookingbutton2.Show();
            cancelBookingbutton2.Show();
            searchBookingbutton2.Show();
            changePasswordbutton.Show();


            cancelBookingbutton2.Show();
            customerInformatiomgroupBox.Show();
            bookinggroupBox.Show();
            IcPassporttextBox.Enabled = true; IcPassporttextBox.Clear(); IcPassportlabel.ForeColor = Color.Black;
            nametextBox.Enabled = true; nametextBox.Clear(); namelabel.ForeColor = Color.Black;
            contactNotextBox.Enabled = false; contactNotextBox.Clear(); contactNolabel.ForeColor = Color.Black;
            emailtextBox.Enabled = false; emailtextBox.Clear(); emaillabel.ForeColor = Color.Black;
            addresstextBox.Enabled = false; addresstextBox.Clear(); addresslabel.ForeColor = Color.Black;
            holidayPackagescomboBox.Enabled = false; holidayPackagescomboBox.SelectedIndex = -1; holidayPackageslabel.ForeColor = Color.Black;
            hotelcomboBox.Enabled = false; hotelcomboBox.SelectedIndex = -1; hotellabel.ForeColor = Color.Black;
            roomcomboBox.Enabled = false; roomcomboBox.SelectedIndex = -1; roomlabel.ForeColor = Color.Black;
            checkIndateTimePicker.Enabled = false;
            checkOutdateTimePicker.Enabled = false;
            searchBookingbutton2.Hide();
            searchBookingbutton.Show();
        }

        private void searchBookingbutton_Click(object sender, EventArgs e)
        {
            if (IcPassporttextBox.Text == "")
            {
                IcPassportlabel.ForeColor = Color.Red;
            }
            if (nametextBox.Text == "")
            {
                namelabel.ForeColor = Color.Red;
            }
            if (IcPassporttextBox.Text == "" || nametextBox.Text == "")
            {
                MessageBox.Show("Please complete the information.");
                return;
            }
            string input_icPassport = IcPassporttextBox.Text, input_name = nametextBox.Text;
            string saved_icpassport, saved_name;
            cmdSearch.CommandText = "Select * from Customer_Information where IC_Passport = \'" + IcPassporttextBox.Text + "\' and Name = \'" + nametextBox.Text + "\' ;";
            cmdSearch.Connection = cnnOLEDB;
            OleDbDataReader dr = cmdSearch.ExecuteReader();
            if (dr.Read() == true)
            {
                saved_icpassport = dr[0].ToString();
                saved_name = dr[1].ToString();
                if (input_icPassport == saved_icpassport && input_name == saved_name)
                {
                    contactNotextBox.Text = dr[2].ToString();
                    emailtextBox.Text = dr[3].ToString();
                    addresstextBox.Text = dr[4].ToString();
                    holidayPackagescomboBox.Text = dr[5].ToString();
                    hotelcomboBox.Text = dr[6].ToString();
                    roomcomboBox.Text = dr[7].ToString();
                    checkIndateTimePicker.MinDate = new DateTime(1985, 6, 20);
                    checkOutdateTimePicker.MinDate = new DateTime(1985, 6, 20);
                    checkIndateTimePicker.Text = dr[8].ToString();
                    checkOutdateTimePicker.Text = dr[9].ToString();
                }
                else
                {
                    MessageBox.Show("Please check your information.");   
                }
                //dr.Close();
                //return;
            }
            else
            {
                MessageBox.Show("Please check your information.");
            }
            dr.Close();
            return;
        }

        private void changePasswordbutton_Click(object sender, EventArgs e)
        {
            newBookingbutton2.Show();
            cancelBookingbutton2.Show();
            searchBookingbutton2.Show();
            changePasswordbutton.Show();

            searchBookingbutton2.Show();
            customerInformatiomgroupBox.Show();
            bookinggroupBox.Show();
            changePasswordgroupBox.Show();
            IcPassporttextBox.Enabled = false; IcPassporttextBox.Clear(); IcPassportlabel.ForeColor = Color.Black;
            nametextBox.Enabled = false; nametextBox.Clear(); namelabel.ForeColor = Color.Black;
            contactNotextBox.Enabled = false; contactNotextBox.Clear(); contactNolabel.ForeColor = Color.Black;
            emailtextBox.Enabled = false; emailtextBox.Clear(); emaillabel.ForeColor = Color.Black;
            addresstextBox.Enabled = false; addresstextBox.Clear(); addresslabel.ForeColor = Color.Black;
            holidayPackagescomboBox.Enabled = false; holidayPackagescomboBox.SelectedIndex = -1; holidayPackageslabel.ForeColor = Color.Black;
            hotelcomboBox.Enabled = false; hotelcomboBox.SelectedIndex = -1; hotellabel.ForeColor = Color.Black;
            roomcomboBox.Enabled = false; roomcomboBox.SelectedIndex = -1; roomlabel.ForeColor = Color.Black;
            checkIndateTimePicker.Enabled = false;
            checkOutdateTimePicker.Enabled = false;
            searchBookingbutton2.Hide();
            searchBookingbutton.Show();
        }

        private void savePasswordbutton_Click(object sender, EventArgs e)
        {
            if(oldPasswordtextBox.Text == "" || newPasswordtextBox.Text == "" || newPassword2textBox.Text == "")
            {
                MessageBox.Show("Please check your information.");
                return;
            }
            else
            {
                string input_old_password = oldPasswordtextBox.Text;
                string saved_password;
                string new_password= newPasswordtextBox.Text;
                string new_password2 = newPassword2textBox.Text;
                cmdSearch.CommandText = "Select * from Account_Password where Account = \'" + account + "\';";
                cmdSearch.Connection = cnnOLEDB;
                OleDbDataReader dr = cmdSearch.ExecuteReader();
                if (dr.Read() == true)
                {
                    saved_password = dr[1].ToString();
                    if(input_old_password == saved_password)
                    {
                        if(new_password == new_password2)
                        {
                            MessageBox.Show("input");
                        }
                        else
                        {
                            MessageBox.Show("The password for the two time is inconsistent.");
                        }
                    }
                    else
                    {
                        MessageBox.Show("The old password is incorrect");
                    }
                }
                dr.Close();
                return;
            }
        }

        private void cancelPasswordbutton_Click(object sender, EventArgs e)
        {
            changePasswordgroupBox.Hide();

        }

        private void logOutbutton_Click(object sender, EventArgs e)
        {
            this.Close();
            Loading_Form loading_form = new Loading_Form();
            loading_form.ShowDialog();
            MessageBox.Show("Log out successfully");
            Login_Form login_form = new Login_Form();
            login_form.Show();
        }


        private void paymentbutton_Click(object sender, EventArgs e)
        {
            Price price = new Price();
            if (holidayPackagescomboBox.SelectedIndex == 0)
            {
                price.holidayPackage_price0();

                if (hotelcomboBox.SelectedIndex == 0)
                {
                    if (roomcomboBox.SelectedIndex == 0)
                    {
                        room_price = 200;
                    }
                    else if(roomcomboBox.SelectedIndex == 1)
                    {
                        room_price = 380;
                    }
                    else if(roomcomboBox.SelectedIndex == 2)
                    {
                        room_price = 600;
                    }
                }
                else if (hotelcomboBox.SelectedIndex == 1)
                {
                    if (roomcomboBox.SelectedIndex == 0)
                    {
                        room_price = 180;
                    }
                    else if (roomcomboBox.SelectedIndex == 1)
                    {
                        room_price = 240;
                    }
                    else if (roomcomboBox.SelectedIndex == 2)
                    {
                        room_price = 400;
                    }
                }
            }
            if(holidayPackagescomboBox.SelectedIndex == 1)
            {
                price.holidayPackage_price1();
                if (hotelcomboBox.SelectedIndex == 0)
                {
                    if (roomcomboBox.SelectedIndex == 0)
                    {
                        room_price = 180;
                    }
                    else if (roomcomboBox.SelectedIndex == 1)
                    {
                        room_price = 350;
                    }
                    else if (roomcomboBox.SelectedIndex == 2)
                    {
                        room_price = 500;
                    }
                }
                else if (hotelcomboBox.SelectedIndex == 1)
                {
                    if (roomcomboBox.SelectedIndex == 0)
                    {
                        room_price = 200;
                    }
                    else if (roomcomboBox.SelectedIndex == 1)
                    {
                        room_price = 360;
                    }
                }
            }
            if (holidayPackagescomboBox.SelectedIndex == 2)
            {
                price.holidayPackage_price2();
                if (hotelcomboBox.SelectedIndex == 0)
                {
                    if (roomcomboBox.SelectedIndex == 0)
                    {
                        room_price = 220;
                    }
                    else if (roomcomboBox.SelectedIndex == 1)
                    {
                        room_price = 350;
                    }
                    else if (roomcomboBox.SelectedIndex == 2)
                    {
                        room_price = 480;
                    }
                }
                else if (hotelcomboBox.SelectedIndex == 1)
                {
                    if (roomcomboBox.SelectedIndex == 0)
                    {
                        room_price = 250;
                    }
                    else if (roomcomboBox.SelectedIndex == 1)
                    {
                        room_price = 380;
                    }
                    else if (roomcomboBox.SelectedIndex == 2)
                    {
                        room_price = 520;
                    }
                }

            }
            if (holidayPackagescomboBox.SelectedIndex == 3)
            {
                price.holidayPackage_price3();
                if (hotelcomboBox.SelectedIndex == 0)
                {
                    if (roomcomboBox.SelectedIndex == 0)
                    {
                        room_price = 180;
                    }
                    else if (roomcomboBox.SelectedIndex == 1)
                    {
                        room_price = 350;
                    }
                    else if (roomcomboBox.SelectedIndex == 2)
                    {
                        room_price = 500;
                    }
                }
                else if (hotelcomboBox.SelectedIndex == 1)
                {
                    if (roomcomboBox.SelectedIndex == 0)
                    {
                        room_price = 200;
                    }
                    else if (roomcomboBox.SelectedIndex == 1)
                    {
                        room_price = 360;
                    }
                }
                else if (hotelcomboBox.SelectedIndex == 2)
                {
                    if (roomcomboBox.SelectedIndex == 0)
                    {
                        room_price = 200;
                    }
                    else if (roomcomboBox.SelectedIndex == 1)
                    {
                        room_price = 380;
                    }
                    else if (roomcomboBox.SelectedIndex == 2)
                    {
                        room_price = 600;
                    }
                }
                else if (hotelcomboBox.SelectedIndex == 3)
                {
                    if (roomcomboBox.SelectedIndex == 0)
                    {
                        room_price = 180;
                    }
                    else if (roomcomboBox.SelectedIndex == 1)
                    {
                        room_price = 240;
                    }
                    else if (roomcomboBox.SelectedIndex == 2)
                    {
                        room_price = 400;
                    }
                }
                else if (hotelcomboBox.SelectedIndex == 4)
                {
                    if (roomcomboBox.SelectedIndex == 0)
                    {
                        room_price = 220;
                    }
                    else if (roomcomboBox.SelectedIndex == 1)
                    {
                        room_price = 350;
                    }
                    else if (roomcomboBox.SelectedIndex == 2)
                    {
                        room_price = 480;
                    }
                }
                else if (hotelcomboBox.SelectedIndex == 5)
                {
                    if (roomcomboBox.SelectedIndex == 0)
                    {
                        room_price = 250;
                    }
                    else if (roomcomboBox.SelectedIndex == 1)
                    {
                        room_price = 380;
                    }
                    else if (roomcomboBox.SelectedIndex == 2)
                    {
                        room_price = 520;
                    }
                }
            }
            int final;
            final = holidayPackage_price + room_price;
            MessageBox.Show("You need to pay RM"+ final+".");

        }

        private void customerInformatiomgroupBox_Enter(object sender, EventArgs e)
        {

        }

        private void addDeleteStaffbutton_Click(object sender, EventArgs e)
        {
            this.Hide();
            AddDelete_Staff addDelete_Staff = new AddDelete_Staff();
            addDelete_Staff.ShowDialog();
            this.Show();
        }

        private void generateReportbutton_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("//Mac//Home//Desktop//Print//IOOP Assignment//IOOP Assignment//bin//Debug//IOOP Assignment.mdb");
        }

        private void newBookingbutton_Click(object sender, EventArgs e)
        {
            if (IcPassporttextBox.Text == "")
            {
                IcPassportlabel.ForeColor = Color.Red;
            }
            if (nametextBox.Text == "")
            {
                namelabel.ForeColor = Color.Red;
            }
            if (contactNotextBox.Text == "")
            {
                contactNolabel.ForeColor = Color.Red;
            }
            if (emailtextBox.Text == "")
            {
                emaillabel.ForeColor = Color.Red;
            }
            if (addresstextBox.Text == "")
            {
                addresslabel.ForeColor = Color.Red;
            }
            if (holidayPackagescomboBox.SelectedIndex == -1)
            {
                holidayPackageslabel.ForeColor = Color.Red;
            }
            if (hotelcomboBox.SelectedIndex == -1)
            {
                hotellabel.ForeColor = Color.Red;
            }
            if (roomcomboBox.SelectedIndex == -1)
            {
                roomlabel.ForeColor = Color.Red;
            }
            if (IcPassportlabel.ForeColor == Color.Red || namelabel.ForeColor == Color.Red || contactNolabel.ForeColor == Color.Red || emaillabel.ForeColor == Color.Red || addresslabel.ForeColor == Color.Red || holidayPackageslabel.ForeColor == Color.Red || hotellabel.ForeColor == Color.Red || roomlabel.ForeColor == Color.Red)
            {
                MessageBox.Show("Please complete the information.");
                return;
            }
            string input_IcPassport, Saved_IcPassport;
            input_IcPassport = IcPassporttextBox.Text;
            cmdSearch.CommandText = "Select * from Customer_Information where IC_Passport = \'" + IcPassporttextBox.Text + "\';";
            cmdSearch.Connection = cnnOLEDB;
            OleDbDataReader dr = cmdSearch.ExecuteReader();
            if (dr.Read() == true)
            {
                Saved_IcPassport = dr[0].ToString();
                dr.Close();
                if (input_IcPassport == Saved_IcPassport)
                {
                    if (MessageBox.Show("The customer already has a reservation, so you are not allowed to add again. \n\r\n\rClick 'OK' to view", "System Prompt", MessageBoxButtons.OKCancel, MessageBoxIcon.Information) == DialogResult.OK)
                    {
                        searchBookingbutton.PerformClick();
                        return;
                    }
                    else
                    {
                        //return;
                    }
                }
            }
            else
            {
                cmdInsert.CommandText = "INSERT INTO Customer_Information VALUES( ('" + IcPassporttextBox.Text + "'),('" + nametextBox.Text + "'),('" + contactNotextBox.Text + "'),('" + emailtextBox.Text + "'),('" + addresstextBox.Text + "'),('" + holidayPackagescomboBox.SelectedItem + "'),('" + hotelcomboBox.SelectedItem + "'),('" + roomcomboBox.SelectedItem + "'),('" + checkIndateTimePicker.Text + "'),('" + checkOutdateTimePicker.Text + "'),('" + DateTime.Now.ToString("dd/MM/yyyy") + "'),('"+DateTime.Now.ToString()+"'))";
                cmdInsert.CommandType = CommandType.Text;
                cmdInsert.Connection = cnnOLEDB;
                cmdInsert.ExecuteNonQuery();
                MessageBox.Show("Insertion Successful");

                newBookingbutton2.Show();
                newBookingbutton.Hide();
                newBookingbutton2.PerformClick();
                dr.Close();
                return;
            }
            cnnOLEDB.Close();
        }
    }
}
