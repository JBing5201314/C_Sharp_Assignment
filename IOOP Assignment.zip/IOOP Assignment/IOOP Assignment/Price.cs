﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IOOP_Assignment
{
    public class Price
    {

        public void holidayPackage_price0()
        {
            int holidayPackage_price = 1200;
        }
        public void holidayPackage_price1()
        {
            int holidayPackage_price = 800;
        }
        public void holidayPackage_price2()
        {
            int holidayPackage_price = 1000;
        }
        public void holidayPackage_price3()
        {
            int holidayPackage_price = 0;
        }
    }
}
