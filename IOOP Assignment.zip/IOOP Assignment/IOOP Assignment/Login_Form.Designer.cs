﻿namespace IOOP_Assignment
{
    partial class Login_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login_Form));
            this.forgotpasswordlinkLabel = new System.Windows.Forms.LinkLabel();
            this.titlelabel = new System.Windows.Forms.Label();
            this.clearAccountpictureBox = new System.Windows.Forms.PictureBox();
            this.exitbutton = new System.Windows.Forms.Button();
            this.loginbutton = new System.Windows.Forms.Button();
            this.passwordtextBox = new System.Windows.Forms.TextBox();
            this.accounttextBox = new System.Windows.Forms.TextBox();
            this.passwordlabel = new System.Windows.Forms.Label();
            this.accountlabel = new System.Windows.Forms.Label();
            this.clearPasswordpictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.clearAccountpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clearPasswordpictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // forgotpasswordlinkLabel
            // 
            this.forgotpasswordlinkLabel.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.forgotpasswordlinkLabel.Location = new System.Drawing.Point(247, 215);
            this.forgotpasswordlinkLabel.Name = "forgotpasswordlinkLabel";
            this.forgotpasswordlinkLabel.Size = new System.Drawing.Size(108, 15);
            this.forgotpasswordlinkLabel.TabIndex = 17;
            this.forgotpasswordlinkLabel.TabStop = true;
            this.forgotpasswordlinkLabel.Text = "Forgot Password?";
            this.forgotpasswordlinkLabel.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.forgotpasswordlinkLabel_LinkClicked);
            // 
            // titlelabel
            // 
            this.titlelabel.AutoSize = true;
            this.titlelabel.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titlelabel.Location = new System.Drawing.Point(79, 50);
            this.titlelabel.Name = "titlelabel";
            this.titlelabel.Size = new System.Drawing.Size(347, 32);
            this.titlelabel.TabIndex = 16;
            this.titlelabel.Text = "Pacific Reservation System";
            // 
            // clearAccountpictureBox
            // 
            this.clearAccountpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("clearAccountpictureBox.Image")));
            this.clearAccountpictureBox.Location = new System.Drawing.Point(334, 135);
            this.clearAccountpictureBox.Name = "clearAccountpictureBox";
            this.clearAccountpictureBox.Size = new System.Drawing.Size(20, 20);
            this.clearAccountpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.clearAccountpictureBox.TabIndex = 15;
            this.clearAccountpictureBox.TabStop = false;
            this.clearAccountpictureBox.Visible = false;
            this.clearAccountpictureBox.Click += new System.EventHandler(this.clearAccountpictureBox_Click);
            // 
            // exitbutton
            // 
            this.exitbutton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.exitbutton.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitbutton.Location = new System.Drawing.Point(284, 274);
            this.exitbutton.Name = "exitbutton";
            this.exitbutton.Size = new System.Drawing.Size(87, 32);
            this.exitbutton.TabIndex = 14;
            this.exitbutton.Text = "Exit";
            this.exitbutton.UseVisualStyleBackColor = true;
            this.exitbutton.Click += new System.EventHandler(this.exitbutton_Click);
            // 
            // loginbutton
            // 
            this.loginbutton.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loginbutton.Location = new System.Drawing.Point(172, 274);
            this.loginbutton.Name = "loginbutton";
            this.loginbutton.Size = new System.Drawing.Size(87, 32);
            this.loginbutton.TabIndex = 13;
            this.loginbutton.Text = "Login";
            this.loginbutton.UseVisualStyleBackColor = true;
            this.loginbutton.Click += new System.EventHandler(this.loginbutton_Click);
            // 
            // passwordtextBox
            // 
            this.passwordtextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passwordtextBox.Location = new System.Drawing.Point(191, 186);
            this.passwordtextBox.Name = "passwordtextBox";
            this.passwordtextBox.Size = new System.Drawing.Size(164, 26);
            this.passwordtextBox.TabIndex = 12;
            this.passwordtextBox.UseSystemPasswordChar = true;
            this.passwordtextBox.TextChanged += new System.EventHandler(this.passwordtextBox_TextChanged);
            // 
            // accounttextBox
            // 
            this.accounttextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.accounttextBox.Location = new System.Drawing.Point(191, 132);
            this.accounttextBox.Name = "accounttextBox";
            this.accounttextBox.Size = new System.Drawing.Size(164, 26);
            this.accounttextBox.TabIndex = 11;
            this.accounttextBox.TextChanged += new System.EventHandler(this.accounttextBox_TextChanged);
            // 
            // passwordlabel
            // 
            this.passwordlabel.AutoSize = true;
            this.passwordlabel.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passwordlabel.Location = new System.Drawing.Point(88, 189);
            this.passwordlabel.Name = "passwordlabel";
            this.passwordlabel.Size = new System.Drawing.Size(81, 19);
            this.passwordlabel.TabIndex = 10;
            this.passwordlabel.Text = "Password :";
            // 
            // accountlabel
            // 
            this.accountlabel.AutoSize = true;
            this.accountlabel.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.accountlabel.Location = new System.Drawing.Point(100, 135);
            this.accountlabel.Name = "accountlabel";
            this.accountlabel.Size = new System.Drawing.Size(72, 19);
            this.accountlabel.TabIndex = 9;
            this.accountlabel.Text = "Account :";
            // 
            // clearPasswordpictureBox
            // 
            this.clearPasswordpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("clearPasswordpictureBox.Image")));
            this.clearPasswordpictureBox.Location = new System.Drawing.Point(334, 189);
            this.clearPasswordpictureBox.Name = "clearPasswordpictureBox";
            this.clearPasswordpictureBox.Size = new System.Drawing.Size(20, 20);
            this.clearPasswordpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.clearPasswordpictureBox.TabIndex = 18;
            this.clearPasswordpictureBox.TabStop = false;
            this.clearPasswordpictureBox.Visible = false;
            this.clearPasswordpictureBox.Click += new System.EventHandler(this.clearPasswordpictureBox_Click);
            // 
            // Login_Form
            // 
            this.AcceptButton = this.loginbutton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.exitbutton;
            this.ClientSize = new System.Drawing.Size(484, 461);
            this.Controls.Add(this.clearPasswordpictureBox);
            this.Controls.Add(this.forgotpasswordlinkLabel);
            this.Controls.Add(this.titlelabel);
            this.Controls.Add(this.clearAccountpictureBox);
            this.Controls.Add(this.exitbutton);
            this.Controls.Add(this.loginbutton);
            this.Controls.Add(this.passwordtextBox);
            this.Controls.Add(this.accounttextBox);
            this.Controls.Add(this.passwordlabel);
            this.Controls.Add(this.accountlabel);
            this.Name = "Login_Form";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Pacific Reservation System";
            this.Load += new System.EventHandler(this.Login_Form_Load);
            ((System.ComponentModel.ISupportInitialize)(this.clearAccountpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clearPasswordpictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.LinkLabel forgotpasswordlinkLabel;
        private System.Windows.Forms.Label titlelabel;
        private System.Windows.Forms.PictureBox clearAccountpictureBox;
        private System.Windows.Forms.Button exitbutton;
        private System.Windows.Forms.Button loginbutton;
        private System.Windows.Forms.TextBox passwordtextBox;
        private System.Windows.Forms.TextBox accounttextBox;
        private System.Windows.Forms.Label passwordlabel;
        private System.Windows.Forms.Label accountlabel;
        private System.Windows.Forms.PictureBox clearPasswordpictureBox;
    }
}

